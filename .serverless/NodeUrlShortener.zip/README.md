# nodejs-shortener
This repo is all about url shortener with nodejs and mongodb 

**URL Shortener Problem**


If you aree having any url - https://youtube.com/c/codeztech
Your output has to be  - https://cdpt.in/Mjg5ODAz


**Evaluation:** <br />
• • Database design/ Data Structure. <br />
• • API structure with appropriate standards. <br />
• • Business Logic. <br />
• • The scope provided for further added features. <br />
• • API and code version support. <br />
• • Logging and Documentation. <br />
• • Quality of code. 


**Steps to Run the Application** <br />
npm install --save <br />
node local.js || node local

**TechStack I used** <br />
NodeJS <br />
MongoDB Cloud <br />
AWS Lambda <br />
AWS API Getway <br />

**API URL** <br />
https://2ocgdhnuwg.execute-api.ap-south-1.amazonaws.com/production

**API Documention URL** <br />

